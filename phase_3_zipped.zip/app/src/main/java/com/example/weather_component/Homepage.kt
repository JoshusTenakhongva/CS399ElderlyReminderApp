package com.example.weather_component

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity


class Homepage : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.homepage)

        val weather_page = findViewById<Button>(R.id.button1)
        val calendar_page = findViewById<Button>(R.id.button2)

        weather_page.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

        calendar_page.setOnClickListener {
            setContentView(R.layout.calendar)
        }
    }
}